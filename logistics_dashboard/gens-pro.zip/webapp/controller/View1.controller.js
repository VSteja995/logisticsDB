sap.ui.define([
    "sap/ui/core/mvc/Controller",
    "sap/ui/model/json/JSONModel",
    "genslogiques/logisticsdashboard/utils/LayoutHelper",
    "sap/m/MessageToast",
    "sap/ui/model/Filter",
    "sap/ui/model/FilterOperator"
], (Controller, JSONModel, LayoutHelper, MessageToast, Filter, FilterOperator) => {
    "use strict";

    return Controller.extend("genslogiques.logisticsdashboard.controller.View1", {

        // ── Lifecycle ────────────────────────────────────────────────────────────
        onInit() {
            // Retrieve the CrossApplicationNavigation service once and cache it.
            // The service is only available when running inside the SAP Fiori Launchpad.
            this._oCrossNav = null;
            if (sap.ushell && sap.ushell.Container) {
                this._oCrossNav = sap.ushell.Container.getService("CrossApplicationNavigation");
            }

            // Store the current date-filter state used for OData calls
            this._oDateFilterState = {
                fromDate: null,  // JavaScript Date | null
                toDate:   null   // JavaScript Date | null
            };
        },

        // ── O/E Schedule  –  Date-Range filter logic ─────────────────────────────

        /**
         * Fired on every change of the DateRangeSelection (live validation).
         * Stores the selected dates in controller state and provides immediate
         * visual feedback via the control's valueState.
         *
         * @param {sap.ui.base.Event} oEvent
         */
        onOEScheduleDateRangeChange: function (oEvent) {
            var oDRS   = oEvent.getSource();
            var dFrom  = oDRS.getDateValue();       // JS Date  |  null
            var dTo    = oDRS.getSecondDateValue(); // JS Date  |  null

            // Basic validation
            if (dFrom && dTo && dFrom > dTo) {
                oDRS.setValueState("Error");
                oDRS.setValueStateText("'From' date must not be after 'To' date.");
                return;
            }

            oDRS.setValueState("None");

            // Cache for use in Apply
            this._oDateFilterState.fromDate = dFrom;
            this._oDateFilterState.toDate   = dTo;
        },

        /**
         * Fired when the user clicks "Apply".
         * Reads the date range, builds OData $filter expressions, then re-binds:
         *   1. The O/E Schedule GridContainer  (DlPnl1Grd018)
         *   2. The Deals Details Table         (DlPnl2Tbl051)
         */
        onOEScheduleApply: function () {
            var oDRS   = this.byId("DlPnl1DRS005");
            var dFrom  = oDRS.getDateValue();
            var dTo    = oDRS.getSecondDateValue();

            // Re-validate before submitting
            if (dFrom && dTo && dFrom > dTo) {
                oDRS.setValueState("Error");
                oDRS.setValueStateText("'From' date must not be after 'To' date.");
                MessageToast.show("Please correct the date range before applying.");
                return;
            }

            if (!dFrom || !dTo) {
                MessageToast.show("Please select a From and To date.");
                return;
            }

            oDRS.setValueState("None");

            // Cache state
            this._oDateFilterState.fromDate = dFrom;
            this._oDateFilterState.toDate   = dTo;

            this._applyOEScheduleFilters(dFrom, dTo);
        },

        /**
         * Builds OData V4-compatible Filter objects and rebinds both the
         * O/E Schedule GridContainer and the Deals Details table.
         *
         * OData V4 uses sap/ui/model/Filter for $filter; for entity sets that
         * use parameters (p_FromDate / p_ToDate) the filters are passed as
         * URL parameters via the binding path instead.
         *
         * @param {Date} dFrom  - start of range (JavaScript Date)
         * @param {Date} dTo    - end of range   (JavaScript Date)
         * @private
         */
        _applyOEScheduleFilters: function (dFrom, dTo) {
            var sFromDate = this._formatODataDate(dFrom); // "YYYY-MM-DD"
            var sToDate   = this._formatODataDate(dTo);

            // ── 1. O/E Schedule GridContainer ────────────────────────────────────
            // The GridContainer uses a relative binding 'DealQtyMotSet'.
            // Pass p_FromDate / p_ToDate as OData function-import parameters
            // via the binding path (OData V4 parametrised entity set notation).
            var oGrid = this.byId("DlPnl1Grd018");
            if (oGrid) {
                oGrid.bindItems({
                    path: "/DealQtyMotSet",
                    parameters: {
                        // OData V4: custom query options sent as URL parameters
                        custom: {
                            p_FromDate: sFromDate,
                            p_ToDate:   sToDate
                        }
                    },
                    template: oGrid.getBindingInfo("items")
                               ? oGrid.getBindingInfo("items").template
                               : undefined
                });
            }

            // ── 2. Deals Details Table ────────────────────────────────────────────
            // Filter on p_FromDate ≤ ScheduleDate ≤ p_ToDate.
            // In OData V4 with sap/ui/model/Filter this translates to a $filter
            // clause on the entity set.
            var oTable = this.byId("DlPnl2Tbl051");
            if (oTable) {
                var oBinding = oTable.getBinding("items");
                if (oBinding) {
                    var aFilters = [
                        new Filter("ScheduleDate", FilterOperator.GE, sFromDate),
                        new Filter("ScheduleDate", FilterOperator.LE, sToDate)
                    ];
                    oBinding.filter(aFilters);
                } else {
                    // Binding not yet initialised – set it with filters inline
                    oTable.bindItems({
                        path: "/xGLQxCM_C_DEALDETAILSSet",
                        filters: [
                            new Filter("ScheduleDate", FilterOperator.GE, sFromDate),
                            new Filter("ScheduleDate", FilterOperator.LE, sToDate)
                        ],
                        template: oTable.getBindingInfo("items")
                                   ? oTable.getBindingInfo("items").template
                                   : undefined
                    });
                }
            }

            MessageToast.show(
                "Showing data from " + sFromDate + " to " + sToDate
            );
        },

        /**
         * Converts a JavaScript Date to the OData Edm.Date string format
         * expected by SAP OData services: "YYYY-MM-DD".
         *
         * @param  {Date}   oDate
         * @returns {string} e.g. "2025-01-31"
         * @private
         */
        _formatODataDate: function (oDate) {
            if (!oDate) { return ""; }
            var iYear  = oDate.getFullYear();
            var iMonth = String(oDate.getMonth() + 1).padStart(2, "0");
            var iDay   = String(oDate.getDate()).padStart(2, "0");
            return iYear + "-" + iMonth + "-" + iDay;
        },

        // ── Cross-App Navigation helpers ─────────────────────────────────────────

        /**
         * Navigate to the Create Deal application.
         * Semantic Object : CommodityManagementDeal
         * Action          : create
         */
        navToCreateDeals: function () {
            this._navigateToIntent("CommodityManagementDeal", "create");
        },

        /**
         * Navigate to the Edit / Lookup Deal application.
         * Semantic Object : CommodityManagementDeal
         * Action          : lookup
         */
        navToEditDeals: function () {
            this._navigateToIntent("CommodityManagementDeal", "lookup");
        },
        /**
         * Navigate to the Create Nomination application.
         * Semantic Object : CommodityManagementDeal
         * Action          : lookup
         */
        navToCreateNomination: function()
        {
            this._navigateToIntent("Nomination", "create");
        },
        navToCreateTicket :function(){
            this._navigateToIntent("Ticket" ," create");
        },
        /**
         * Generic cross-application navigation with intent-support check.
         * @param {string} sSemanticObject  - Fiori semantic object
         * @param {string} sAction          - Fiori action
         */
        _navigateToIntent: function (sSemanticObject, sAction) {
            var oCrossNav = this._oCrossNav;

            // Guard: service unavailable (e.g. running standalone, not in Launchpad)
            if (!oCrossNav) {
                MessageToast.show(
                    "Navigation service is unavailable. " +
                    "Please run the app inside the SAP Fiori Launchpad."
                );
                return;
            }

            var oTarget = {
                target: {
                    semanticObject: sSemanticObject,
                    action: sAction
                }
                // No params needed – omitted intentionally per requirements
            };

            // Best practice: check intent support before navigating
            oCrossNav.isIntentSupported([sSemanticObject + "-" + sAction])
                .done(function (oSupportedIntents) {
                    var sIntent = sSemanticObject + "-" + sAction;
                    if (oSupportedIntents[sIntent] && oSupportedIntents[sIntent].supported) {
                        oCrossNav.toExternal(oTarget);
                    } else {
                        MessageToast.show(
                            "Navigation to '" + sSemanticObject + "#" + sAction +
                            "' is not supported for your user role."
                        );
                    }
                })
                .fail(function () {
                    MessageToast.show(
                        "Could not verify navigation intent. Please try again."
                    );
                });
        },

        // ── Layout helpers ───────────────────────────────────────────────────────
        onFullScreenToggle: function (oEvent) {
            LayoutHelper.toggleFullScreen(oEvent);
        }
    });
});